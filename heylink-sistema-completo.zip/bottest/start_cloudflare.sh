#!/bin/bash

echo "🌐 Iniciando Heylink com Cloudflare Tunnel..."
echo "================================================"

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Verificar se cloudflared está instalado
if ! command -v cloudflared &> /dev/null; then
    echo -e "${YELLOW}⚠️  Cloudflared não encontrado. Instalando...${NC}"
    
    # Detectar sistema operacional
    if [[ "$OSTYPE" == "linux-gnu"* ]]; then
        if command -v apt &> /dev/null; then
            # Ubuntu/Debian
            wget -q https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64.deb
            sudo dpkg -i cloudflared-linux-amd64.deb
            rm cloudflared-linux-amd64.deb
        elif command -v yum &> /dev/null; then
            # CentOS/RHEL/Fedora
            wget -q https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64.rpm
            sudo rpm -i cloudflared-linux-amd64.rpm
            rm cloudflared-linux-amd64.rpm
        else
            echo -e "${RED}❌ Sistema não suportado para instalação automática${NC}"
            echo "Instale manualmente: https://developers.cloudflare.com/cloudflare-one/connections/connect-apps/install-and-setup/installation/"
            exit 1
        fi
    else
        echo -e "${RED}❌ Sistema não suportado para instalação automática${NC}"
        echo "Instale manualmente: https://developers.cloudflare.com/cloudflare-one/connections/connect-apps/install-and-setup/installation/"
        exit 1
    fi
    
    echo -e "${GREEN}✅ Cloudflared instalado com sucesso!${NC}"
else
    echo -e "${GREEN}✅ Cloudflared já está instalado${NC}"
fi

# Verificar versão
CLOUDFLARED_VERSION=$(cloudflared --version 2>/dev/null | head -n1)
echo -e "${BLUE}📦 Versão: $CLOUDFLARED_VERSION${NC}"

# Verificar se Flask está rodando
echo -e "${YELLOW}🔍 Verificando se Flask está rodando...${NC}"
if curl -s http://localhost:8000 > /dev/null; then
    echo -e "${GREEN}✅ Flask já está rodando na porta 8000${NC}"
    FLASK_RUNNING=true
else
    echo -e "${YELLOW}🚀 Iniciando Flask...${NC}"
    
    # Ativar ambiente virtual se existir
    if [ -f "venv/bin/activate" ]; then
        source venv/bin/activate
        echo -e "${GREEN}✅ Ambiente virtual ativado${NC}"
    fi
    
    # Iniciar Flask em background
    python app.py &
    FLASK_PID=$!
    FLASK_RUNNING=false
    
    # Aguardar Flask iniciar
    echo -e "${YELLOW}⏳ Aguardando Flask inicializar...${NC}"
    for i in {1..10}; do
        if curl -s http://localhost:8000 > /dev/null; then
            echo -e "${GREEN}✅ Flask iniciado com sucesso!${NC}"
            FLASK_RUNNING=true
            break
        fi
        sleep 1
        echo -n "."
    done
    
    if [ "$FLASK_RUNNING" = false ]; then
        echo -e "${RED}❌ Erro ao iniciar Flask${NC}"
        exit 1
    fi
fi

echo ""
echo -e "${BLUE}📡 Criando túnel Cloudflare...${NC}"
echo -e "${YELLOW}⚠️  Aguarde alguns segundos para o túnel ser criado...${NC}"
echo ""

# Iniciar túnel Cloudflare
cloudflared tunnel --url http://localhost:8000

# Cleanup ao sair (se Flask foi iniciado por este script)
if [ ! -z "$FLASK_PID" ]; then
    trap "echo -e '\n${YELLOW}🛑 Parando Flask...${NC}'; kill $FLASK_PID 2>/dev/null" EXIT
fi